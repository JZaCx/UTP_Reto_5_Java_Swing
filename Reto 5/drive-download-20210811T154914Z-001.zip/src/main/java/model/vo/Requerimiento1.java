package model.vo;

public class Requerimiento1 {
    //Su codigo
    //Atributos y los setters y getters
    
}
