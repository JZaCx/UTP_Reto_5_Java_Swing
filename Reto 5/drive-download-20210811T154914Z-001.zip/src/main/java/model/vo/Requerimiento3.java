package model.vo;

public class Requerimiento3 {
    //su codigo  
}
