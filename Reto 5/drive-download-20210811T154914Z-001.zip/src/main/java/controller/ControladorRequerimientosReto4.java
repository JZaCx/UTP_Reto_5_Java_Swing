package controller;

//Estructuras de datos (colecciones)
import java.util.ArrayList;

//Modelos (acceso y objetos contenedores)
import model.dao.Requerimiento1_Dao;
import model.dao.Requerimiento2_Dao;
import model.dao.Requerimiento3_Dao;
import model.vo.Requerimiento_1;
import model.vo.Requerimiento_2;
import model.vo.Requerimiento_3;


//Librerías para bases de datos
import java.sql.SQLException;

public class ControladorRequerimientos {       
    //Su codigo
    
    public ControladorRequerimientosReto4(){
        //Su codigo

    }

    public ArrayList<Requerimiento_1> consultarRequerimiento_1() throws SQLException {
        //Su codigo
    }
    
    public ArrayList<Requerimiento_2> consultarRequerimiento_2() throws SQLException {
        //Su codigo
    }

    public ArrayList<Requerimiento_3> consultarRequerimiento_3() throws SQLException {
        //Su codigo
    }

}
